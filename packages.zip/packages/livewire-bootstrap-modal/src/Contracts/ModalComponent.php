<?php

namespace LivewireBootstrapModal\Contracts;

interface ModalComponent
{

}
