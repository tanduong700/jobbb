const mix = require('laravel-mix');

//mix.js('resources/js/livewire-bootstrap-modal.js', 'public/')
